    var webview = document.getElementById('c-agg');
    webview.addEventListener('dom-ready', function () {
        webview.insertCSS('div[role=article]{ background: #343538 !important;}') //tweets in home view
        webview.insertCSS('.rn-1mlj4tw{ background-color: #343538 !important;}')
        webview.insertCSS('.rn-bauka4{ background-color: #2a2b2d !important;}') //full width buttons like in 'account settings'
        webview.insertCSS('.rn-mikf4x{ background-color: #444549 !important;}') //class that gets added to things on hover
        webview.insertCSS('.rn-bauka4:hover{ background-color: #343538 !important;}')//"show this thread" button
        webview.insertCSS('div[data-testid=primaryColumn]{ background-color: #2a2b2d; !important;}') //background columns
        webview.insertCSS('.element.style{ background-color: #343538; !important;}')
        webview.insertCSS('.rn-1mlj4tw{ background-color: #343538 !important;}')
        // webview.insertCSS('.rn-44z8sh{ background-color: #343538 !important;}')
        webview.insertCSS('ul[role=list]{ background-color: #343538; !important;}') //menu items in header
        webview.insertCSS('ul[role=list]:hover{ background-color: #343538 !important;}') //menu items in header: hover
        webview.insertCSS('div[data-testid=tweetDetail]{ background: #343538 !important;}') //tweets in notifications
        webview.insertCSS('article{ background: #343538 !important;}')
        webview.insertCSS('._1_KafmK5{ background-color: #F5F8FA !important;}')
        webview.insertCSS('.rn-10ytdpq{display: none !important;')
        webview.insertCSS('header:not(form) { display: none !important;}') //standard app header
        webview.insertCSS('html{font-size: 13px !important;}') //all text on page, font size
        webview.insertCSS('._2t1-zb7t {border-bottom-color: #1da1f2 !important;}')
        webview.insertCSS('._2t1-zb7t {color: black !important;}')
        webview.insertCSS('.rn-bauka4{ color: #ededed !important}') //this line can change the text color
        webview.insertCSS('.rn-q9ob72:hover{ color: #ededed !important}') //this line can change the text color
        webview.insertCSS('.rn-84x3in{ border-bottom-color: #3d4154 !important}') //this line can change the text color
        webview.insertCSS('.rn-1mnldmn{ padding-bottom: 0px !important;}') //this line can change the text color
    });

//this script handles css injection