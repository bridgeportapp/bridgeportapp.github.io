function newTweet(){
	window.open('./minAppComp.html', '_blank', 'location=1,height=250,width=500,scrollbars=yes,status=yes');
}

function backChecker(){
	if ( document.getElementById("c-agg").canGoBack() == 'false' ) {
		console.log("yes it can")
	} else {
		console.log("no it can't")
	}
}

const {BrowserWindow} = require('electron').remote;
// Retrieve focused window
var theWindow = BrowserWindow.getFocusedWindow();

function windShow(){
	theWindow.setOpacity(1)
}

function closeWin(){
	var wSize = theWindow.getSize().toString()
	localStorage["sizeHW"] = wSize
	console.log("live:" + wSize)
	console.log("stored:" + localStorage["sizeHW"])
	theWindow.close()
}
// function closeWin(){
// 	var wSize = theWindow.getSize().toString()
// 	var winHeight = wSize.slice(0, 3)
// 	var winWidth = wSize.slice(-3)
// 	localStorage["sizeH"] = winHeight
// 	localStorage["sizeW"] = winWidth
// 	console.log("live:" + winHeight +","+ winWidth)
// 	console.log("stored:" +  localStorage["sizeH"] +","+ localStorage["sizeW"])
// 	// theWindow.close()
// }

function sizeClear(){
	localStorage["sizeH"] = ""
	localStorage["sizeW"] = ""
}

function tParent(){
	document.getElementById("darwin-title-bar").ondblclick = untParent;
	theWindow.setOpacity(0.7)
}

function untParent(){
	document.getElementById("darwin-title-bar").ondblclick = tParent;
	theWindow.setOpacity(1)
}

function winMaximize(){
	document.getElementById("titleMaximize").onclick = winUnmaximize;
	theWindow.maximize()
}

function winUnmaximize(){
	document.getElementById("titleMaximize").onclick = winMaximize;
	theWindow.unmaximize()
}

// window.setInterval(backChecker,600)
setTimeout(function() { windShow(); }, 250);