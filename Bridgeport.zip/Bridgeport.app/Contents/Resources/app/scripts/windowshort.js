function newTweet(){
	window.open('./minAppComp.html', '_blank', 'location=1,height=250,width=500,scrollbars=yes,status=yes');
}

const {BrowserWindow} = require('electron').remote;
// Retrieve focused window
var theWindow = BrowserWindow.getFocusedWindow();

function windShow(){
	theWindow.setOpacity(1)
}

function closeWin(){
	var wSize = theWindow.getSize().toString()
	localStorage["sizeHW"] = wSize
	console.log("live:" + wSize)
	console.log("stored:" + localStorage["sizeHW"])
	theWindow.close()
}
// function closeWin(){
// 	var wSize = theWindow.getSize().toString()
// 	var winHeight = wSize.slice(0, 3)
// 	var winWidth = wSize.slice(-3)
// 	localStorage["sizeH"] = winHeight
// 	localStorage["sizeW"] = winWidth
// 	console.log("live:" + winHeight +","+ winWidth)
// 	console.log("stored:" +  localStorage["sizeH"] +","+ localStorage["sizeW"])
// 	// theWindow.close()
// }

function sizeClear(){
	localStorage["sizeH"] = ""
	localStorage["sizeW"] = ""
}

function tParent(){
	document.getElementById("darwin-title-bar").ondblclick = untParent;
	theWindow.setOpacity(0.8)
}

function untParent(){
	document.getElementById("darwin-title-bar").ondblclick = tParent;
	theWindow.setOpacity(1)
}

function winMaximize(){
	document.getElementById("titleMaximize").onclick = winUnmaximize;
	theWindow.maximize()
}

function winUnmaximize(){
	document.getElementById("titleMaximize").onclick = winMaximize;
	theWindow.unmaximize()
}

	console.log(" ")
	console.log("You probably shouldn't be in here if you don't know what you're doing")
	console.log(" ")
	console.log("Also I'd advise changing the view to external window by clicking the three dots in the top")
	console.log("right corner and then clicking the icon that looks like two windows.")
	console.log(" ")

function fwdChecker(){
	var canFWD = webview.canGoForward()
	if(canFWD == false){
		document.getElementById("gofwd").style.display = "none"
	} else {
		document.getElementById("gofwd").style.display = "inline"
}}

function backChecker(){
	var canGB = webview.canGoBack()
	if(canGB == false){
		document.getElementById("goback").style.display = "none"
	} else {
		document.getElementById("goback").style.display = "inline"
}}

// window.setInterval(backChecker,600)
setTimeout(function() { windShow(); }, 250);
window.setInterval(fwdChecker, 150);
window.setInterval(backChecker, 150);













