var session = localStorage['firstRun'];

if (session != "false"){
	window.location.href = "firstrun/index.html";
} else{
	//do nothing
}