// var storedHW = localStorage["sizeHW"]
// var hwarray = storedHW.split(',')

// // theWindow.setSize(storedHW)