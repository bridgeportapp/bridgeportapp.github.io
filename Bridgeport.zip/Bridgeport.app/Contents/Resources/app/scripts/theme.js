var theme = localStorage["theme"]
var rEdges = localStorage["roundedEdges"]
var bigFont = localStorage["bigFont"]

if (theme != "light"){
         var webview = document.getElementById('c-agg');
         webview.addEventListener('dom-ready', function () {
        //app specific rules
        webview.insertCSS('header:not(form) { display: none !important;}') //standard app header
        webview.insertCSS('.rn-10ytdpq{display: none !important;') //twitter new tweet button
        webview.insertCSS('@keyframes bp-fadein {from { opacity: 0; }, to { opacity: 1; }}') //bp-fadein animation definition
        webview.insertCSS('@keyframes bp-slidein {from { opacity: 0; }, to { opacity: 1; }}') //bp-fadein animation definition
        webview.insertCSS('div[role="article"] { animation: bp-fadein 300ms; }') //tweet animation
        webview.insertCSS('div[data-testid="tweetDetail"] { animation: bp-fadein 300ms; }') //tweet detail animation
        webview.insertCSS('*{ cursor: default !important; }') //default cursor for everything
        webview.insertCSS('*{ animation: bp-fadien 300ms; }') //everything fades in
        webview.insertCSS('.rn-19nsbbv{display: none !important;}') //that stupid padding at top of the nav on profiles
        //theme specific rules
        webview.insertCSS('div[role="article"] { background: #343538 !important;}') //tweets
        webview.insertCSS('.rn-bauka4{ color: #ededed !important}') //this line can change the text color
        webview.insertCSS('.rn-1uhmdza{ background: #5e6066 !important}') //anything with a background of rgb(204, 214, 221); poll results
        webview.insertCSS('.rn-1mlj4tw{ background: #444548 !important}') //anything with a background of rgb(230, 236, 240) (follows you button)
        webview.insertCSS('.rn-cwv21{ background: #252525 !important}') //hover effect for most things (quoted tweets + show this thread)
        webview.insertCSS('.rn-1u4rsef{ background: #252525 !important}') //hover effect for most things (quoted tweets + show this thread)
        webview.insertCSS('.rn-169w83h{background-color: #303030 !important;}') //:active
        webview.insertCSS('.rn-vqp9x9{background-color: #303030 !important;}') //:active
        webview.insertCSS('.rn-mikf4x{ background-color: #252525 !important}') //hover effect for ul (menu on profile)
        webview.insertCSS('.rn-44z8sh{ background: #343538 !important}') //white elements
        webview.insertCSS('.rn-e84r5y{ background: #343538 !important}') //white elements
        webview.insertCSS('.rn-84x3in{border-bottom-color: #202a30 !important;}') //bottom border for tweets
        webview.insertCSS('div[data-testid=primaryColumn]{ background-color: #343538 !important;}') //background
        webview.insertCSS('.rn-1ou8vq3{ background-color: #5e6066 !important;}') //unread notification
        webview.insertCSS('ul[role=list]{ background-color: #343538; !important;}') //menu items in header
        webview.insertCSS('div[aria-label=Loading…]{ background: transparent !important;}') //loading content
        webview.insertCSS('html{font-size: 13px !important;}') //changes all text to 13px
        webview.insertCSS('body{ background-color: #343538 !important;}') //body background
        webview.insertCSS('.rn-1pi2tsx{ background-color: transparent !important;}') //photo view background
        // webview.insertCSS('*[role="listitem"]{background: linear-gradient(#212121,#0f0f0f) !important; padding-top: 0px;}') //nav is sticky
        webview.insertCSS('*[role="listitem"]{background: #191919 !important; padding-top: 0px;}') //nav is sticky
        // webview.insertCSS('.rn-q9ob72{color: red !important;}') //nav is sticky
        webview.insertCSS('.rn-q9ob72{color: #ededed !important;}') //stop fucking changing shit, twitter (underline color)
        webview.insertCSS('.rn-hkyrab{color: #ededed !important;}') //stop fucking changing shit, twitter (underline color)
        webview.insertCSS('.rn-14lw9ot{background: #343538 !important;}') //more stupid white shit
        webview.insertCSS('.rn-vrwoeq{background: #444548 !important;}') //underlined text color
        webview.insertCSS('div{border-color: #444548 !important;}') //underlined text color
        webview.insertCSS('ul{border-color: #444548 !important;}') //underlined text color
        webview.insertCSS('.rn-my5ep6{border-color: #444548 !important;}') //underlined text color
        webview.insertCSS('.DraftEditor-editorContainer{border-left: 0px solid transparent !important;}') //underlined text color


    });
} else {
        var webview = document.getElementById('c-agg');
        webview.addEventListener('dom-ready', function () {
        //app specific rules
        webview.insertCSS('header:not(form) { display: none !important;}') //standard app header
        webview.insertCSS('.rn-10ytdpq{display: none !important;') //twitter new tweet button
        webview.insertCSS('@keyframes bp-fadein {from { opacity: 0; }, to { opacity: 1; }}') //bp-fadein animation definition
        webview.insertCSS('@keyframes bp-slidein {from { opacity: 0; }, to { opacity: 1; }}') //bp-fadein animation definition
        webview.insertCSS('div[role="article"] { animation: bp-fadein 600ms; }') //tweet animation
        webview.insertCSS('div[data-testid="tweetDetail"] { animation: bp-fadein 600ms; }') //tweet detail animation
        webview.insertCSS('*{ cursor: default !important; }') //default cursor for everything
        webview.insertCSS('*{ animation: bp-fadien 600ms; }') //everything fades in
    });

}

if (rEdges == "enabled"){
         var webview = document.getElementById('c-agg');
         webview.addEventListener('dom-ready', function () {
            webview.insertCSS('.rn-qb5c1y{border-bottom-left-radius: 999px !important;}') //bottom left radius
            webview.insertCSS('.rn-sqtsar{border-bottom-right-radius: 999px !important;}') //bottom right radius
            webview.insertCSS('.rn-waaub4{border-top-right-radius: 999px !important;}') //top right radius
            webview.insertCSS('.rn-1bxrh7q{border-top-left-radius: 999px !important;}') //top left radius
    });
} else {
        var webview = document.getElementById('c-agg');
        webview.addEventListener('dom-ready', function () {
        //app specific rules
            webview.insertCSS('.rn-qb5c1y{border-bottom-left-radius: 4px !important;}') //bottom left radius
            webview.insertCSS('.rn-sqtsar{border-bottom-right-radius: 4px !important;}') //bottom right radius
            webview.insertCSS('.rn-waaub4{border-top-right-radius: 4px !important;}') //top right radius
            webview.insertCSS('.rn-1bxrh7q{border-top-left-radius: 4px !important;}') //top left radius
    });

}


if (bigFont == "enabled"){
         var webview = document.getElementById('c-agg');
         webview.addEventListener('dom-ready', function () {
            webview.insertCSS('html{font-size: 16px !important;}') //changes all text to 13px
    });
} else {
        var webview = document.getElementById('c-agg');
        webview.addEventListener('dom-ready', function () {
            webview.insertCSS('html{font-size: 13px !important;}') //changes all text to 13px
    });

}








