function error() {
	document.getElementById('errorsnd').play();
	window.alert('An error has occured at ' + er)
	window.close()
}