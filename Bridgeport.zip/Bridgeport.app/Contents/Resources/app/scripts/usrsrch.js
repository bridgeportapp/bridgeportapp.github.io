var searchField = document.getElementById("searchbar");
var userInput;
undefined = () => {},


//here for compatibilit
function parser() {
	alert('hello')
	var stage0 = userInput.string()
	var stage1 = stage0.replace(' ','+')
	var stage2 = stage1.replace('#','%23')
	var stage3 = stage2.replace('@','40')
}

// function regSearch(){
// 	var userInput = searchField.value
// 	var stage1 = userInput.replace(" ","+")
// 	var stage2 = stage1.replace("#","%23")
// 	var stage3 = stage2.replace("@","%40")
// 	webview.loadURL('https://mobile.twitter.com/search?q=' + stage3);
// 	barInvisible();
// }

function regSearch(){
	var userInput = searchField.value
	if (userInput.startsWith("@")){
		var stage1 = userInput.replace(" ","")
		var stage2 = stage1.replace("#","%23")
		webview.loadURL('https://mobile.twitter.com/' + stage2);
		barInvisible();
	}else{
		var stage1 = userInput.replace(" ","+")
		var stage2 = stage1.replace("#","%23")
		var stage3 = stage2.replace("@","%40")
		webview.loadURL('https://mobile.twitter.com/search?q=' + stage3);
		barInvisible();
	}
}


function barVisible(){
	var userInput;
	document.getElementById("searchbarcontainer").style.display = "inline"
	document.getElementById("searchbg").style.display = "inline"
	document.getElementById("c-agg").style.transform = "scale(0.95)"
	document.getElementById("searchbutton").onclick = barInvisible;
	document.getElementById("searchbar").focus();
}

function barInvisible(){
	document.getElementById("searchbarcontainer").style.display = "none"
	document.getElementById("searchbg").style.display = "none"
	document.getElementById("c-agg").style.transform = "scale(1)"
	document.getElementById("searchbutton").onclick = barVisible;
	searchField.value = ""
}

document.getElementById("searchbar")
    .addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode === 13) {
        document.getElementById("searchicon").click();
    }
});



// //replace spaces with "+"
// //replace "#" with "%23"
// //replace "@" with "%40"
