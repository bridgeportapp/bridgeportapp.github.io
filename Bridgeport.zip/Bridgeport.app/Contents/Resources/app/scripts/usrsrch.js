var searchField = document.getElementById("searchbar");
var userInput;
undefined = () => {},


//this is the text parsing bit
function parser() {
	alert('hello')
	var stage0 = userInput.string()
	var stage1 = stage0.replace(' ','+')
	var stage2 = stage1.replace('#','%23')
	var stage3 = stage2.replace('@','40')
}

function regSearch(){
	var userInput = searchField.value
	var stage1 = userInput.replace(" ","+")
	var stage2 = stage1.replace("#","%23")
	var stage3 = stage2.replace("@","%40")
	webview.loadURL('https://mobile.twitter.com/search?q=' + stage3);
	barInvisible();
}


function barVisible(){
	var userInput;
	document.getElementById("searchbarcontainer").style.display = "inline"
	document.getElementById("searchbg").style.display = "inline"
	// document.getElementById("c-agg").style.opacity = "0.1"
	document.getElementById("c-agg").style.pointerEvents = "none"
	document.getElementById("searchbutton").onclick = barInvisible;
}

function barInvisible(){
	document.getElementById("searchbarcontainer").style.display = "none"
	document.getElementById("searchbg").style.display = "none"
	// document.getElementById("c-agg").style.opacity = "1.0"
	document.getElementById("c-agg").style.pointerEvents = "auto"
	document.getElementById("searchbutton").onclick = barVisible;
	searchField.value = ""
}




// //replace spaces with "+"
// //replace "#" with "%23"
// //replace "@" with "%40"
