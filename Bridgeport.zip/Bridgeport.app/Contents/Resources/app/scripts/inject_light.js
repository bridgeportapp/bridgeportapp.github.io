    var webview = document.getElementById('c-agg');
   	 webview.addEventListener('dom-ready', function () {
       //app specific rules
        webview.insertCSS('header:not(form) { display: none !important;}') //standard app header
        webview.insertCSS('.rn-10ytdpq{display: none !important;') //twitter new tweet button
        webview.insertCSS('.rn-qb5c1y{border-bottom-left-radius: 4px !important;}') //bottom left radius
        webview.insertCSS('.rn-sqtsar{border-bottom-right-radius: 4px !important;}') //bottom right radius
        webview.insertCSS('.rn-waaub4{border-top-right-radius: 4px !important;}') //top right radius
        webview.insertCSS('.rn-1bxrh7q{border-top-left-radius: 4px !important;}') //top left radius
        webview.insertCSS('html{font-size: 13px !important;}') //changes all text to 13px
        webview.insertCSS('@keyframes bp-fadein {from { opacity: 0; }, to { opacity: 1; }}') //bp-fadein animation definition
        webview.insertCSS('div[role="article"] { animation: bp-fadein 400ms; }') //tweet animation
        webview.insertCSS('div[data-testid="tweetDetail"] { animation: bp-fadien 400ms; }') //tweet detail animation
        webview.insertCSS('*{ cursor: default !important; }') //default cursor for everything
    });

//this script handles css injection