// function hasOneDayPassed(){
//   var date = new Date().toLocaleDateString();

//   if( localStorage.yourapp_date == date ) 
//       return false;

//   localStorage.yourapp_date = date;
//   return true;
// }

// // some function which should run once a day
// function runOncePerDay(){
//   if( !hasOneDayPassed() ) return false;

//   // your code below
//   alert('Good morning!');
// }


var updateOpt = localStorage["noUpdates"]
if(updateOpt == "noCheck"){
	console.log("will not check for update: auto updates opted out of")
}else{
	
	var date = new Date().toLocaleDateString();
	if (localStorage["date"] == date){
		console.log("will not check for update: already checked for update today")
	} else{
		console.log("checking for updates in 5s")
		setTimeout(function() { miniUpd(); }, 5000);
	}
	
	localStorage["date"] = date
	
	function miniUpd(){
		if (currentVersionServer > currentVersionLocal){
			document.getElementById("updatewindow").style.display = "inline";
			document.getElementById('errorsnd').play();
		} else{
			console.log("no updates available")
		}
	}
	
}

function updateOptOut(){
	localStorage["noUpdates"] = "noCheck"
	document.getElementById("updatewindow").style.display = "none"
	console.log("will never check for updates")
}

function updateLater(){
	document.getElementById("updatewindow").style.display = "none"
}

function updateDownload(){
	window.location = "https://bridgeportapp.github.io/Bridgeport.zip"
	document.getElementById("updatewindow").style.display = "none"
}

