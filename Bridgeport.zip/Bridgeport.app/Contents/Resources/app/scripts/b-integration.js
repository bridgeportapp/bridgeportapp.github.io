// const {BrowserWindow} = require('electron').remote
const shell = require('electron').shell;


if (localStorage["inAppBrowser"] == "disabled"){
 	webview.addEventListener('new-window', (e) => {
    const protocol = require('url').parse(e.url).protocol
    if (protocol === 'http:' || protocol === 'https:') {
      shell.openExternal(e.url)
    }
})
}else {
 	webview.addEventListener('new-window', (e) => {
    const protocol = require('url').parse(e.url).protocol
    if (protocol === 'http:' || protocol === 'https:') {
    let win = new BrowserWindow({width: 1024, height: 700})
    win.loadURL(e.url);
    }
  })
}