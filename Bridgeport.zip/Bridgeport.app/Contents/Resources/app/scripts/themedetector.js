// backdrop2

if (localStorage["theme"] == "dark"){
	//do nothing
} else{
	document.getElementById("backdrop2").style.background = "white"
	document.getElementById("darwin-title-bar").style.background = "white"
	document.getElementById("searchbarcontainer").style.background = "#ededed"
	document.getElementById("darwin-title-bar").style.borderBottom = "1px solid #a4a2a4"
	document.getElementById("searchbarcontainer").style.borderBottom = "1px solid #a4a2a4"
	document.getElementById("titletext").style.color = "black"
	document.getElementById("goback").style.color = "#444"
	document.getElementById("gofwd").style.color = "#444"
	document.getElementById("backdrop").style.background = "#004e6d"
	document.getElementById("ppbg").style.background = "rgba(255,255,255,0.6)"
	document.getElementById("searchbg").style.background = "rgba(255,255,255,0.6)"
	document.getElementById("searchicon").style.color = "black"
	document.getElementById("searchbar").style.color = "black"
	document.getElementById("triangle-bottomleft").style.borderBottom = "4px solid #004e6d"
	document.getElementById("triangle-topleft").style.borderTop = "4px solid #004e6d"
	document.getElementById("prefpane").style.background = "#004e6d"
	document.getElementById("prefpane").style.boxShadow = "0px 0px 20px #2121219f"
	document.getElementById("pptext").style.color = "#ededed"
}

if (localStorage["roundedEdges"] == "disabled"){
	//do nothing
} else{
	document.getElementById("searchbarcontainer").style.borderRadius = "999px"
}

if (localStorage["angledEdge"] == "enabled"){
	//do nothing
} else{
	document.getElementById("triangle-bottomleft").style.display = "none"
	document.getElementById("triangle-topleft").style.display = "none"
}