function lightMode(){
	localStorage['theme'] = 'lm'; // only strings
	document.getElementById("theme").src = "inject_light.js"
}

function darkMode(){
	//do nothing
}

var th = localStorage['theme']

if (th != "lm"){
	alert("darkMode is on")
	var lm = ""
} else{
	document.getElementById("theme").src = "inject_light.js"
	document.getElementById("c-agg").reload
}



var er = "CSS_THEME_ERROR (#002)"