function missionControl(){
	var tl = webview.getTitle() //this creates a variable with the page title as "tl"
		var tle = tl.replace('Twitter','Bridgeport') //this replaces the "twitter" text from variable tl to say "Bridgeport"
	document.getElementById('missctrltxt').innerHTML = tle //this changes the header text at the top of the app
}

function headerTitle(){
	var tl = webview.getTitle() //this creates a variable with the page title as "tl"
	var tle = tl.replace('Twitter','Bridgeport') //this replaces the "twitter" text from variable tl to say "Bridgeport"
	if (tle.startsWith('https:')){
		var tlee = "Bridgeport"
	} else{
		var tlee = tle
	}
	document.getElementById('titletext').innerHTML = tlee
}

function focusCheck(){
	if (document.hasFocus()) {
    document.getElementById("titleClose").classList.remove('dimtitlebtn')
    document.getElementById("titleMinimize").classList.remove('dimtitlebtn')
    document.getElementById("titleMaximize").classList.remove('dimtitlebtn')
    document.getElementById("darwin-title-bar").classList.remove('dimstatusbar')
    document.getElementById("searchbarcontainer").classList.remove('dimstatusbar')
} else{
	document.getElementById("titleClose").classList.add('dimtitlebtn')
	document.getElementById("titleMinimize").classList.add('dimtitlebtn')
	document.getElementById("titleMaximize").classList.add('dimtitlebtn')
	document.getElementById("darwin-title-bar").classList.add('dimstatusbar')
	document.getElementById("searchbarcontainer").classList.add('dimstatusbar')
}
}




webview.addEventListener("page-title-updated", headerTitle);
window.setInterval(headerTitle, 150) //updates header text once every x milliseconds
window.setInterval(missionControl, 1250) //updates mission control text once every x milliseconds
window.setInterval(focusCheck, 10) //checks window focus every 10ms so that the buttons grey out on inactive

