function aucToggleCheck(){
	var updateOpt = localStorage["noUpdates"]	
	if(updateOpt == "noCheck"){
		document.getElementById("updatetoggle").className = "toggle-off"
		document.getElementById("updatetoggle").onclick = aucON
	} else{
		document.getElementById("updatetoggle").className = "toggle-on"
		document.getElementById("updatetoggle").onclick = aucOFF
	}
}

window.setInterval(aucToggleCheck, 40)

function aucON(){
	localStorage["noUpdates"] = ""
	console.log("aucON")
}

function aucOFF(){
	localStorage["noUpdates"] = "noCheck"
	console.log("aucOFF")
}

function dmToggleCheck(){
	var updateDM = localStorage["theme"]	
	if(updateDM != "light"){
		document.getElementById("darkmodetoggle").className = "toggle-off"
		document.getElementById("darkmodetoggle").onclick = dmON
	} else{
		document.getElementById("darkmodetoggle").className = "toggle-on"
		document.getElementById("darkmodetoggle").onclick = dmOFF
	}
}

window.setInterval(dmToggleCheck, 40)

function dmON(){
	localStorage["theme"] = "light"
	alert("You MUST restart Bridgeport for this to take effect")
}

function dmOFF(){
	localStorage["theme"] = "dark"
	alert("You MUST restart Bridgeport for this to take effect")
}