// auto update check settings
function aucToggleCheck(){
	var updateOpt = localStorage["noUpdates"]	
	if(updateOpt == "noCheck"){
		document.getElementById("updatetoggle").className = "toggle-off"
		document.getElementById("updatetoggle").onclick = aucON
	} else{
		document.getElementById("updatetoggle").className = "toggle-on"
		document.getElementById("updatetoggle").onclick = aucOFF
	}
}

window.setInterval(aucToggleCheck, 40)

function aucON(){
	localStorage["noUpdates"] = ""
	console.log("aucON")
}

function aucOFF(){
	localStorage["noUpdates"] = "noCheck"
	console.log("aucOFF")
}
//dark mode settings
function dmToggleCheck(){
	var updateDM = localStorage["theme"]	
	if(updateDM != "light"){
		document.getElementById("darkmodetoggle").className = "toggle-off"
		document.getElementById("darkmodetoggle").onclick = dmON
	} else{
		document.getElementById("darkmodetoggle").className = "toggle-on"
		document.getElementById("darkmodetoggle").onclick = dmOFF
	}
}

window.setInterval(dmToggleCheck, 40)

function dmON(){
	localStorage["theme"] = "light"
	rAlertShow()
}

function dmOFF(){
	localStorage["theme"] = "dark"
	rAlertShow()
}


// in app browser settings
function iabON(){
	localStorage["inAppBrowser"] = "enabled"
	rAlertShow()
	console.log("iabON")
}

function iabOFF(){
	localStorage["inAppBrowser"] = "disabled"
	rAlertShow()
	console.log("iabOFF")
}

function iabToggleCheck(){
	var updateIAB = localStorage["inAppBrowser"]	
	if(updateIAB == "disabled"){
		document.getElementById("iabtoggle").className = "toggle-off"
		document.getElementById("iabtoggle").onclick = iabON
	} else{
		document.getElementById("iabtoggle").className = "toggle-on"
		document.getElementById("iabtoggle").onclick = iabOFF
	}
}

window.setInterval(iabToggleCheck, 40)

function rAlertShow()
{
	document.getElementById('restart-alert').style.display = "inline"
}

// in app browser settings
function reON(){
	localStorage["roundedEdges"] = "enabled"
	rAlertShow()
	console.log("reON")
}

function reOFF(){
	localStorage["roundedEdges"] = "disabled"
	rAlertShow()
	console.log("reOFF")
}

function iabToggleCheck(){
	var updateIAB = localStorage["roundedEdges"]	
	if(updateIAB == "disabled"){
		document.getElementById("roundedgestoggle").className = "toggle-off"
		document.getElementById("roundedgestoggle").onclick = reON
	} else{
		document.getElementById("roundedgestoggle").className = "toggle-on"
		document.getElementById("roundedgestoggle").onclick = reOFF
	}
}

window.setInterval(iabToggleCheck, 40)

function rAlertShow()
{
	document.getElementById('restart-alert').style.display = "inline"
	document.getElementById('restart-warn').style.display = "none"
}

// big font settings
function bfON(){
	localStorage["bigFont"] = "enabled"
	rAlertShow()
	console.log("bfON")
}

function bfOFF(){
	localStorage["bigFont"] = "disabled"
	rAlertShow()
	console.log("bfOFF")
}

function bfToggleCheck(){
	var updateBF = localStorage["bigFont"]	
	if(updateBF == "disabled"){
		document.getElementById("bigfonttoggle").className = "toggle-off"
		document.getElementById("bigfonttoggle").onclick = bfON
	} else{
		document.getElementById("bigfonttoggle").className = "toggle-on"
		document.getElementById("bigfonttoggle").onclick = bfOFF
	}
}

window.setInterval(bfToggleCheck, 40)

function rAlertShow()
{
	document.getElementById('restart-alert').style.display = "inline"
	document.getElementById('restart-warn').style.display = "none"
}

// angled edge settings
function angON(){
	localStorage["angledEdge"] = "enabled"
	rAlertShow()
	console.log("bfON")
}

function angOFF(){
	localStorage["angledEdge"] = "disabled"
	rAlertShow()
	console.log("bfOFF")
}

function angToggleCheck(){
	var updateang = localStorage["angledEdge"]	
	if(updateang == "disabled"){
		document.getElementById("angletoggle").className = "toggle-off"
		document.getElementById("angletoggle").onclick = angON
	} else{
		document.getElementById("angletoggle").className = "toggle-on"
		document.getElementById("angletoggle").onclick = angOFF
	}
}

window.setInterval(angToggleCheck, 40)

function rAlertShow()
{
	document.getElementById('restart-alert').style.display = "inline"
	document.getElementById('restart-warn').style.display = "none"
}






