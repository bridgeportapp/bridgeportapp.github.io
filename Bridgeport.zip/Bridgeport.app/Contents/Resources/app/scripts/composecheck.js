function composeTitleChecker() {
 var cc = tweet.getURL() //this gets webview title
 	if (cc != 'https://mobile.twitter.com/compose/tweet') {
 		window.close()
 	} else {
		//do absolutely fucking nothing
 	}
 	// console.log(cc)
}
window.setInterval(composeTitleChecker, 400) //checks every x miliseconds
window.setInterval(windowSize, 400) //checks every x miliseconds

function windowSize(){
	var height = document.body.scrollHeight
}

theWindow.setAlwaysOnTop(true)