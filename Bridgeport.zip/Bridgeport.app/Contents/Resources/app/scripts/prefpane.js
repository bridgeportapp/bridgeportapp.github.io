function prefPaneShow(){
	document.getElementById("prefpane").style.display = "inline"
	document.getElementById("morebutton").onclick = prefPaneHide;
	document.getElementById("ppbg").style.display = "inline"
	document.getElementById("c-agg").style.transform = "scale(0.95)"
}

function prefPaneHide(){
	document.getElementById("prefpane").style.display = "none"
	document.getElementById("morebutton").onclick = prefPaneShow;
	document.getElementById("ppbg").style.display = "none"
	document.getElementById("c-agg").style.transform = "scale(1)"
}

function ppFollowing(){
	webview.loadURL('http://mobile.twitter.com/following')
}

function ppMessages(){
	webview.loadURL('https://mobile.twitter.com/messages/compose')
}

function ppFollowers(){
	webview.loadURL('https://mobile.twitter.com/followers')
}

function ppLikes(){
	webview.loadURL('https://twitter.com/i/likes')
}

function ppMe(){
	webview.loadURL('https://mobile.twitter.com/account')
}

function ppSettings(){
	webview.loadURL('https://mobile.twitter.com/settings/')
}

function ppExplore(){
	webview.loadURL('https://mobile.twitter.com/explore')
}

function ppAlwaysTop(){
	document.getElementById("ppAlwaysOnTop").onclick = ppRegBehave;
	document.getElementById("ppRadioBtn1").textContent = "radio_button_checked";
	// localStorage["topStatus"] = "true"
	theWindow.setAlwaysOnTop(true)
}

function ppRegBehave(){
	document.getElementById("ppAlwaysOnTop").onclick = ppAlwaysTop;
	document.getElementById("ppRadioBtn1").textContent = "radio_button_unchecked";
	// localStorage["topStatus"] = "false"
	theWindow.setAlwaysOnTop(false)
}

function ppEyeBleach(){
	webview.loadURL('https://mobile.twitter.com/hourlywolvesbot/media')
}

// function ppYesUpd(){
// 	document.getElementById("ppAutoUpdBtn").onclick = ppNoUpd;
// 	document.getElementById("ppRadioBtn2").textContent = "radio_button_checked";
// 	localStorage["noUpdates"] = "";
// }

// function ppNoUpd(){
// 	document.getElementById("ppAutoUpdBtn").onclick = ppYesUpd;
// 	document.getElementById("ppRadioBtn2").textContent = "radio_button_unchecked";
// 	localStorage["noUpdates"] = "noUpdates";
// }



// function ppUpdCheck(){
// 	var upd = localStorage["noUpdates"]
// 	if (upd == "noCheck") {
// 		ppNoUpd()
// 	} else{
// 		ppYesUpd()
// 	}
// }

ppUpdCheck()
window.setInterval(ppUpdCheck,200)















