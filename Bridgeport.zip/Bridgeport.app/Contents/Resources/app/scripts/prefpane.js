function prefPaneShow(){
	document.getElementById("prefpane").style.display = "inline"
	document.getElementById("morebutton").onclick = prefPaneHide;
	document.getElementById("ppbg").style.display = "inline"
}

function prefPaneHide(){
	document.getElementById("prefpane").style.display = "none"
	document.getElementById("morebutton").onclick = prefPaneShow;
	document.getElementById("ppbg").style.display = "none"
}

function ppFollowing(){
	webview.loadURL('http://mobile.twitter.com/following')
}

function ppFollowers(){
	webview.loadURL('https://mobile.twitter.com/followers')
}

function ppLikes(){
	webview.loadURL('https://twitter.com/i/likes')
}

function ppMe(){
	webview.loadURL('https://mobile.twitter.com/account')
}

function ppSettings(){
	webview.loadURL('https://mobile.twitter.com/settings/')
}

function ppExplore(){
	webview.loadURL('https://mobile.twitter.com/explore')
}

function ppAlwaysTop(){
	document.getElementById("ppAlwaysOnTop").onclick = ppRegBehave;
	document.getElementById("ppRadioBtn1").textContent = "radio_button_checked";
	// localStorage["topStatus"] = "true"
	theWindow.setAlwaysOnTop(true)
}

function ppRegBehave(){
	document.getElementById("ppAlwaysOnTop").onclick = ppAlwaysTop;
	document.getElementById("ppRadioBtn1").textContent = "radio_button_unchecked";
	// localStorage["topStatus"] = "false"
	theWindow.setAlwaysOnTop(false)
}

function ppEyeBleach(){
	webview.loadURL('https://mobile.twitter.com/hourlywolvesbot/media')
}

var top = localStorage["topStatus"]

if (top == "true") {
	//ppAlwaysOnTop()
} else{
	//ppRegBehave()
}

















