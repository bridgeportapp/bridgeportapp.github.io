console.log("bridgeport webview manager loaded")

//this section prevents drag in
 document.addEventListener('dragover',function(event){
    event.preventDefault();
    return false;
  },false);

  document.addEventListener('drop',function(event){
    event.preventDefault();
    return false;
  },false);

console.log("no drag implemented")

//this section selects links and makes them clickable
function linkUpd(){
	var links = document.querySelectorAll("a[role=link]")
}
window.setInterval(linkUpd, 500)