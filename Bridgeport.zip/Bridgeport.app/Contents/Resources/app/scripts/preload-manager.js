console.log("bridgeport webview manager loaded")

//this section prevents drag in
 document.addEventListener('dragover',function(event){
    event.preventDefault();
    return false;
  },false);

  document.addEventListener('drop',function(event){
    event.preventDefault();
    return false;
  },false);

console.log("no drag implemented")

//this section selects links and makes them clickable
function linkUpd(){
	document.querySelectorAll('[role="link"]').id = "potentiallink"
	document.getElementById("potentiallink").removeAttribute("target")
	console.log("links remove targeted")
}

// window.setInterval(linkUpd, 500)