function logincheck() {
 var cc = document.getElementById('l-field').getURL() //this gets webview URL
 	if (cc.startsWith('https://mobile.twitter.com/login')){
 		//don't do a fuckin thing boi
 	} else {
		window.location.href = "finishing.html"
 	}
}
window.setInterval(logincheck, 750) //checks every x miliseconds
