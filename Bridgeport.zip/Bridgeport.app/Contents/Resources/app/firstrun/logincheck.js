function logincheck() {
 var cc = document.getElementById('l-field').getURL() //this gets webview URL
 	if (cc.startsWith('https://mobile.twitter.com/login')){
 		//don't do a fuckin thing boi
 	} else {
		window.location.href = "finishing.html"
 	}
}
function routines(){
	window.setInterval(logincheck, 100) //checks every x miliseconds	
}

document.getElementById("l-field").addEventListener("dom-ready", routines);
