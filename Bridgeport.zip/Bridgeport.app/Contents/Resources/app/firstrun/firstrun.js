function cont(){
	window.location.href = "../index.html";
	localStorage['firstRun'] = 'false'; // only strings
}

function eulashow(){
	document.getElementById("all1").style.display = "none",
	document.getElementById("all2").style.display = "inline"
}

function disagree(){
	error()
}

function agree(){
	window.location.href = "finishing.html"
}


var er = "TERMS_CONDITIONS_AGREEMENT_PAGE (#0001)"