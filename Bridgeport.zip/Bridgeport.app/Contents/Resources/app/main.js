const electron = require('electron');
const app = electron.app;
const BrowserWindow = electron.BrowserWindow;
const Menu = electron.Menu;
const path = require('path');
const shell = require('electron').shell;
const globalShortcut = require('electron')

let browserWindow = null;

function createWindow() //window properties.
{
  browserWindow = new BrowserWindow({
    width: 570, 
    height: 750, 
    // titleBarStyle:"hidden-inset", 
    // vibrancy:"dark", 
    backgroundColor: '#212123',
    // transparent: true,
    maxWidth: 666, 
    minWidth: 370,
    minHeight: 512,
    fullscreen: false,
    frame: false,
    opacity: 0,
    webPreferences: {
      experimentalFeatures: true
    },
    preload: __dirname + '/promptconfig.js'
    }); //creates the window in which the user will interact with the app


  // browserWindow.loadURL(path.join('file://', __dirname, '/firstrun/index.html')); //first run ui
  browserWindow.loadURL(path.join('file://', __dirname, '/index.html')); //main app content

  browserWindow.on('closed', () => {browserWindow = null;});

  const template = //define the menu template
  [
    {
      label: 'File', //File menu
      submenu: [
        {
          label: 'Compose New Tweet',
          click () {newTweet()},
          accelerator: 'CmdOrCtrl+N',
        } //,
        // {
        //   label: 'New Fullscreen Instance',
        //   click () {fullscreen()},
        //   accelerator: 'CmdOrCtrl+F',
        // }
      ]
    },
    {
      label: 'Edit', //edit menu
      submenu: [
        {role: 'undo'},
        {role: 'redo'},
        {type: 'separator'},
        {role: 'cut'},
        {role: 'copy'},
        {role: 'paste'},
        {role: 'delete'},
        {role: 'selectall'},
      ]
    },
    {
      role: 'window', //window menu
      submenu: [
        {role: 'minimize'},
        {role: 'close'},
        {role: 'front'},
      ]
    },
    {
      role: 'help', //help menu
      submenu: [
      {
          label: 'Bridgeport Help',
          click () {dont()},
          accelerator: 'CmdOrCtrl+Shift+H',
        }
      ]
    },
    { //disable here
      label: 'Developer', //Developer Menu
      submenu: [
        {role: 'toggledevtools'},
        {type: 'separator'},
        {role: 'reload'},
        {
          label: 'Framework Versions',
          click () {diagWindow()},
          accelerator: 'CmdOrCtrl+Shift+V',
        }
      ]
    }, //to here
  ]

  if (process.platform === 'darwin') {
    template.unshift({
      label: app.getName(),
      submenu: [
         {
          label: 'About Bridgeport',
          click () {aboutWindow()}
        },
        {
          label: 'Updates and Changelog',
          click () {dont()}
        },
        {type: 'separator'},
        {role: 'services', submenu: []},
        {type: 'separator'},
        {role: 'hide'},
        {role: 'hideothers'},
        {role: 'unhide'},
        {type: 'separator'},
        {role: 'quit'}
      ]
    })

    // Edit menu
    template[1].submenu.push(
      {type: 'separator'},
      {
        label: 'Speech',
        submenu: [
          {role: 'startspeaking'},
          {role: 'stopspeaking'}
        ]
      }
    )

    // Window menu
    template[3].submenu = [
      {role: 'close'},
      {role: 'minimize'},
      {role: 'zoom'},
      {type: 'separator'},
      {role: 'front'}
    ]
  }


  let menu = Menu.buildFromTemplate(template); //build the menu from the established template
  Menu.setApplicationMenu(menu); //apply the menu
}


app.on('ready', () => {createWindow();}); //when the app is ready the window will be created

app.on('activate', function ()
{ if (browserWindow === null){createWindow()}}); //make a new window after the first one has been closed

app.on('window-all-closed', () =>
{if(process.platform !== 'darwin'){app.quit()}}); //quit the app on non-darwin systems (though irrelevant here, i'll keep it for future)

function aboutWindow() //makes the about window
{
  browserWindow = new BrowserWindow({
    width: 383, 
    height: 383, 
    titleBarStyle:"hidden", 
    vibrancy:"menu", 
    resizable: false,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppAbt.html')); //loads app ui
}

function diagWindow() //makes the diagnostics window
{
  browserWindow = new BrowserWindow({
    width: 512, 
    height: 368, 
    titleBarStyle:"hidden", 
    maxWidth: 512, 
    minWidth: 512,
    minHeight: 368,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppDevDiag.html')); //loads app ui
}

function newTweet() //makes the compose window
{
  browserWindow = new BrowserWindow({
    width: 500, 
    height: 250, 
    frame: false,
    fullscreen: false,
    backgroundColor: '#FFF',
    // maxWidth: 500, 
    minWidth: 500,
    minHeight: 220,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppComp.html')); //loads app ui
}