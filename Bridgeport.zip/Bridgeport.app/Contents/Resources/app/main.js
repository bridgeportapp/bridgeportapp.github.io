const electron = require('electron');
// const app = electron.app;
const BrowserWindow = electron.BrowserWindow;
const Menu = electron.Menu;
const path = require('path');
const shell = require('electron').shell;
const {app, globalShortcut} = require('electron')

let browserWindow = null;
// app.disableHardwareAcceleration()
function mainWindow() //window properties.
{
  browserWindow = new BrowserWindow({
    width: 570, 
    height: 750, 
    backgroundColor: '#212123',
    maxWidth: 666,  
    minWidth: 370,
    minHeight: 512,
    // fullscreen: false,
    frame: false,
    opacity: 0,
    webPreferences: { experimentalFeatures: true },
    // preload: __dirname + '/promptconfig.js'
    }); //creates the window in which the user will interact with the app

  browserWindow.loadURL(path.join('file://', __dirname, '/index.html')); //main app content

  browserWindow.on('closed', () => {browserWindow = null;});
  // browserWindow.on('closed', () => {browserWindow.hide()});


  const template = //define the menu template
  [
    {
      label: 'File', //File menu
      submenu: [
        {
          label: 'Compose New Tweet',
          click () {newTweet()},
          accelerator: 'Option+Shift+N',
        }
      ]
    },
    {
      label: 'Edit', //edit menu
      submenu: [
        {role: 'undo'},
        {role: 'redo'},
        {type: 'separator'},
        {role: 'cut'},
        {role: 'copy'},
        {role: 'paste'},
        {role: 'delete'},
        {role: 'selectall'},
      ]
    },
    {
      role: 'window', //window menu
      submenu: [
        {role: 'minimize'},
        {role: 'close'},
        {role: 'front'},
      ]
    },
    {
      role: 'help', //help menu
      submenu: [
      {
          label: 'Bridgeport Help',
          // click () {dont()},
          accelerator: 'CmdOrCtrl+Shift+H',
        },
        {
          label: 'Support the Developer',
          click () { require('electron').shell.openExternal('https://www.paypal.me/StateraAF') }
        },  
        {
          label: 'Report Bug / Request Feature',
          submenu: [
            {
            label: '...via email',
            click () { require('electron').shell.openExternal('mailto:bridgeportfortwitter@gmail.com') }
            },
            {
            label: '...via twitter',
            click () { require('electron').shell.openExternal('https://twitter.com/BridgeportApp') }
            },
          ]
        },
      ]
    },
    // { //disable here
    //   label: '⌘', //Developer Menu
    //   submenu: [
    //     {role: 'toggledevtools'},
    //     {type: 'separator'},
    //     {role: 'reload'},
    //     {
    //       label: 'Developer Information',
    //       click () {diagWindow()},
    //       accelerator: 'CmdOrCtrl+Shift+D+I',
    //     }
    //   ]
    // }, //to here
  ]

  if (process.platform === 'darwin') {
    template.unshift({
      label: app.getName(),
      submenu: [
         {
          label: 'About Bridgeport',
          click () {aboutWindow()},
        },
        {type: 'separator'},
        {
          label: 'Preferences',
          click () {prefWindow()},
          accelerator: 'CmdOrCtrl+,',
        },
        {
          label: 'Check for Updates...',
          click () {updCheck()}
        },
        {
          label: 'Changelog...',
          click () {patchNotes()}
        },
        {type: 'separator'},
        {role: 'services', submenu: []},
        {type: 'separator'},
        {role: 'hide'},
        {role: 'hideothers'},
        {role: 'unhide'},
        {type: 'separator'},
        {
          label: 'Restart',
          role: 'reload',
          accelerator: '',
        },
        {role: 'quit'}
      ]
    })

    // Edit menu
    template[1].submenu.push(
      {type: 'separator'},
      {
        label: 'Speech',
        submenu: [
          {role: 'startspeaking'},
          {role: 'stopspeaking'}
        ]
      }
    )

    // Window menu
    template[3].submenu = [
      {role: 'close'},
      {role: 'minimize'},
      {role: 'zoom'},
      {type: 'separator'},
      {role: 'front'}
    ]
  }
  
  //dock menu
  const dockMenu = Menu.buildFromTemplate([
    { label: 'Bridgeport for Twitter'},
    { type: 'separator'},
    {
      label: 'Compose New Tweet...',
      click () { newTweet() }
    }, 
    {
      label: 'Check for Updates...',
      click () { updCheck() }
    },

    {
      label: 'Report Bug / Request Feature',
      submenu: [
        {
          label: '...via email',
          click () { require('electron').shell.openExternal('mailto:bridgeportfortwitter@gmail.com') }
        },
        {
         label: '...via twitter',
         click () { require('electron').shell.openExternal('https://twitter.com/BridgeportApp') }
        },
        ]
      }
  ])
  



  let menu = Menu.buildFromTemplate(template); //build the menu from the established template
  Menu.setApplicationMenu(menu); //apply the menu
  app.dock.setMenu(dockMenu) 
}

function aboutWindow() //makes the about window
{
  browserWindow = new BrowserWindow({
    width: 383, 
    height: 383, 
    titleBarStyle:"hidden", 
    vibrancy:"dark", 
    resizable: false,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppAbt.html')); //loads app ui
}

function diagWindow() //makes the diagnostics window
{
  browserWindow = new BrowserWindow({
    width: 512, 
    height: 542, 
    titleBarStyle:"hidden", 
    maxWidth: 512, 
    minWidth: 512,
    minHeight: 368,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppDevDiag.html')); //loads app ui
}

function newTweet() //makes the compose window
{
  browserWindow = new BrowserWindow({
    width: 500, 
    height: 250, 
    maxWidth: 500,  
    frame: false,
    fullscreen: false,
    backgroundColor: '#FFF',
    // maxWidth: 500, 
    minWidth: 500,
    minHeight: 220,
    opacity: 1,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppComp.html')); //loads app ui
}

function updCheck() //makes the update checker window
{
  browserWindow = new BrowserWindow({
    width: 500, 
    height: 220,
    maxWidth: 500, 
    maxHeight: 250,
    minWidth: 500,
    minHeight: 220, 
    titleBarStyle: "hidden",
    fullscreen: false,
    backgroundColor: '#313131',
    // maxWidth: 500, 
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppUpd.html')); //loads app ui
}

function patchNotes() //makes the patchnotes window
{
  browserWindow = new BrowserWindow({
    width: 500, 
    height: 500,
    maxWidth: 500, 
    maxHeight: 500,
    resizable: false, 
    titleBarStyle: "hidden",
    fullscreen: false,
    backgroundColor: '#212121',
    minWidth: 500,
    minHeight: 500,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppPatchNotes.html')); //loads app ui
}

function prefWindow() //makes the compose window
{
  browserWindow = new BrowserWindow({
    width: 500, 
    height: 500,
    maxWidth: 500, 
    maxHeight: 500,
    resizable: false, 
    titleBarStyle: "hidden",
    fullscreen: false,
    backgroundColor: '#343538',
    minWidth: 500,
    minHeight: 500,
    });
  browserWindow.loadURL(path.join('file://', __dirname, '/minAppPref.html')); //loads app ui
}

app.on('ready', () => {
    //register the key shortcut, THEN launches the main window
    const ret = globalShortcut.register('Option+Shift+N', () => {
      newTweet()
    })

    mainWindow()

  })
  
  app.on('will-quit', () => {
    // Unregister all shortcuts.
    globalShortcut.unregisterAll()
  })

// app.on('ready', () => {createWindow();}); //when the app is ready the window will be created

app.on('activate', function ()
{ if (browserWindow === null){mainWindow()}}); //make a new window after the first one has been closed

app.on('window-all-closed', () =>
{if(process.platform !== 'darwin'){app.quit()}}); //quit the app on non-darwin systems (though irrelevant here, i'll keep it for future)




